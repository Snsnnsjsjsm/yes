# TikTok-AutoClaimer

The art of sending millions of requests per second in order to claim a specific TikTok username, also known as Autoclaiming.
